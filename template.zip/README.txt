Animation: CSS плюс JS
Coding: CSS, HTML, JQuery, JS, SCSS, PUG
Features: Адаптивний
Script: Акордеон, Карусель
Installation: Инструкции по использованию нахордятся в файле Documentation.html
Functionality: landing
Language support: English, Russian